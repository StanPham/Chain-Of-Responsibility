/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package chainofresponsibility;

import chainofresponsibility.handler.GenreHandler;
import chainofresponsibility.handler.Handler;
import chainofresponsibility.handler.TitleHandler;
import chainofresponsibility.handler.YearHandler;

/**
 *
 * @author Stan
 */
public class Client {
    private Handler handler;

    public Client() {
        this.handler = new TitleHandler(
                       new GenreHandler(
                       new YearHandler(null)));
    }

    public void getMovieInfo(Movie movie, String request) {
        String info = handler.handleMovie(movie, request);
        if (info != null) {
            System.out.println(info);
        } else {
            System.out.println("Invalid request");
        }
    }
}

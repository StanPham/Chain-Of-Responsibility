/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package chainofresponsibility;

/**
 *
 * @author Stan
 */
public class ChainOfResponsbility {
    
    public static void main(String[] args) {
        Movie movie1 = new Movie("The Shawshank Redemption", "Drama", 1994);
        Movie movie2 = new Movie("The Godfather", "Crime", 1972);
        Movie movie3 = new Movie("The Dark Knight", "Action", 2008);
        
        Client client = new Client();
        client.getMovieInfo(movie1, "title");
        client.getMovieInfo(movie2, "genre");
        client.getMovieInfo(movie3, "year");
        client.getMovieInfo(movie1, "director");
    }
    
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package chainofresponsibility.handler;

import chainofresponsibility.Movie;

/**
 *
 * @author Stan
 */
public class YearHandler implements Handler {
    private Handler successor;
    
     public YearHandler(Handler successor) {
        this.successor = successor;
    }
    

    @Override
    public void setSuccessor(Handler successor) {
        this.successor = successor;
    }

    @Override
    public String handleMovie(Movie movie, String request) {
        if(request.toLowerCase().equals("year")){
            return "Year: " + movie.getYear();
        } else if(successor != null){
            return successor.handleMovie(movie, request);
        } else {
            return null;
        }
    }
}

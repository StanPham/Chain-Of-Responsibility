/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package chainofresponsibility.handler;

import chainofresponsibility.Movie;

/**
 *
 * @author Stan
 */
public class GenreHandler implements Handler{
    private Handler successor;

    public GenreHandler(Handler successor) {
        this.successor = successor;
    }

    @Override
    public String handleMovie(Movie movie, String request) {
        if(request.toLowerCase().equals("genre")){
            return "Genre: " + movie.getGenre();
        } else if(successor != null){
            return successor.handleMovie(movie, request);
        } else {
            return null;
        }
    }

    @Override
    public void setSuccessor(Handler successor) {
        this.successor = successor;
    }
}

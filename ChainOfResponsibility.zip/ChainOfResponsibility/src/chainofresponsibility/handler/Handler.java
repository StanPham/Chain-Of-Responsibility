/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package chainofresponsibility.handler;

import chainofresponsibility.Movie;

/**
 *
 * @author Stan
 */
public interface Handler {
    void setSuccessor(Handler successor);
    String handleMovie(Movie movie, String request);
}
